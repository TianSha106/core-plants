
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.coreplants.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.coreplants.block.IronPlantsBlock;
import net.mcreator.coreplants.block.GoldPlantsBlock;
import net.mcreator.coreplants.block.DimondPlantsBlock;
import net.mcreator.coreplants.CorePlantsMod;

public class CorePlantsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, CorePlantsMod.MODID);
	public static final RegistryObject<Block> IRON_PLANTS = REGISTRY.register("iron_plants", () -> new IronPlantsBlock());
	public static final RegistryObject<Block> DIAMOND_PLANTS = REGISTRY.register("diamond_plants", () -> new DimondPlantsBlock());
	public static final RegistryObject<Block> GOLD_PLANTS = REGISTRY.register("gold_plants", () -> new GoldPlantsBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
