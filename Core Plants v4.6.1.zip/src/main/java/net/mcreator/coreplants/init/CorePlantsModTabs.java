
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.coreplants.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.coreplants.CorePlantsMod;

public class CorePlantsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CorePlantsMod.MODID);
	public static final RegistryObject<CreativeModeTab> CORE_PLANTS = REGISTRY.register("core_plants",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.core_plants.core_plants")).icon(() -> new ItemStack(CorePlantsModBlocks.IRON_PLANTS.get())).displayItems((parameters, tabData) -> {
				tabData.accept(CorePlantsModBlocks.IRON_PLANTS.get().asItem());
				tabData.accept(CorePlantsModBlocks.DIAMOND_PLANTS.get().asItem());
				tabData.accept(CorePlantsModBlocks.GOLD_PLANTS.get().asItem());
			})

					.build());
}
